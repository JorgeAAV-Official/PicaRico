
const fs = require('fs');
const https = require('https');
const express = require('express');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const morgan = require('morgan');

const app = express();
app.use(bodyParser.json());
app.use(morgan('dev'));


const JWT_SECRET = process.env.JWT_SECRET || 'cambiar_esto_por_un_secreto_muy_largo';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '60m'; 


const estudiantes = [
  { id: 1, nombre: 'Ana Perez', programa: 'Ingeniería de Software' },
  { id: 2, nombre: 'Carlos Ramírez', programa: 'Sistemas' },
  { id: 3, nombre: 'María Gómez', programa: 'Contabilidad' }
];


app.get('/', (req, res) => {
  res.json({ mensaje: 'Servicio seguro (prueba). Usa /login y /api/estudiantes' });
});


app.post('/login', (req, res) => {
  const { usuario, password } = req.body;


  if (!usuario || !password) {
    return res.status(400).json({ error: 'usuario y password requeridos' });
  }


  if (usuario === 'alumno' && password === '1234') {
    const payload = {
      sub: usuario,
      rol: 'estudiante'
    };
    const token = jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
    return res.json({ token, expiresIn: JWT_EXPIRES_IN });
  }

  return res.status(401).json({ error: 'Credenciales inválidas' });
});


function autenticarJWT(req, res, next) {
  const authHeader = req.headers['authorization'] || req.headers['Authorization'];
  if (!authHeader) {
    return res.status(401).json({ error: 'No se proporcionó cabecera Authorization' });
  }

  const parts = authHeader.split(' ');
  if (parts.length !== 2 || parts[0] !== 'Bearer') {
    return res.status(401).json({ error: 'Formato de Authorization inválido. Use: Bearer <token>' });
  }

  const token = parts[1];

  jwt.verify(token, JWT_SECRET, (err, decoded) => {
    if (err) {
     
      if (err.name === 'TokenExpiredError') {
        return res.status(401).json({ error: 'Token expirado' });
      }
      return res.status(401).json({ error: 'Token inválido' });
    }
  
    req.user = decoded;
    next();
  });
}


app.get('/api/estudiantes', autenticarJWT, (req, res) => {
  res.json({ data: estudiantes });
});


const keyPath = './certs/server.key';
const certPath = './certs/server.crt';


if (!fs.existsSync(keyPath) || !fs.existsSync(certPath)) {
  console.error('No se encontraron certificados en ./certs/. Genera certificados autofirmados o usa ngrok. Más info en README.');
  process.exit(1);
}

const httpsOptions = {
  key: fs.readFileSync(keyPath),
  cert: fs.readFileSync(certPath)
};

const PORT = process.env.PORT || 3000;
https.createServer(httpsOptions, app).listen(PORT, () => {
  console.log(`Servidor HTTPS escuchando en https://localhost:${PORT}`);
});
